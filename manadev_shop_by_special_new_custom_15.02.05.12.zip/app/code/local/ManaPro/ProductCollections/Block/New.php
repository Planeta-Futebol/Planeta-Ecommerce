<?php
/**
 * @category    Mana
 * @package     ManaPro_ProductCollections
 * @copyright   Copyright (c) http://www.manadev.com
 * @license     http://www.manadev.com/license  Proprietary License
 */
/**
 * @author Mana Team
 *
 */
class ManaPro_ProductCollections_Block_New extends ManaPage_New_Block_Filter {
    // class left for compatibility
}