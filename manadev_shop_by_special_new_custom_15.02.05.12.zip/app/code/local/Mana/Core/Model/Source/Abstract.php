<?php
/**
 * @category    Mana
 * @package     Mana_Core
 * @copyright   Copyright (c) http://www.manadev.com
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * Base class for source classes used to populate SELECT drop downs with values
 * @author Mana Team
 *
 */
abstract class Mana_Core_Model_Source_Abstract {
	protected $_options = null;
	 
    /**
     * Retrieve all options array
     *
     * @return array
     */
    public function getAllOptions()
    {
        if (is_null($this->_options)) {
            $this->_options = $this->_getAllOptions();
        }
        return $this->_options;
    }

    protected abstract function _getAllOptions();
    
    /**
     * Retrieve option array
     *
     * @return array
     */
    public function getOptionArray()
    {
        $_options = array();
        foreach ($this->getAllOptions() as $option) {
            if(!is_array($option['value'])) {
                $_options[$option['value']] = $option['label'];
            } else {
                $_options[] = $option['label'];
            }
        }
        return $_options;
    }

    /**
     * Get a text for option value
     *
     * @param string|integer $value
     * @return string
     */
    public function getOptionText($value)
    {
        $options = $this->getAllOptions();
        foreach ($options as $option) {
            if ($option['value'] == $value) {
                return $option['label'];
            }
        }
        return false;
    }

	public function toOptionArray() {
		return $this->getOptionArray();
	}
}