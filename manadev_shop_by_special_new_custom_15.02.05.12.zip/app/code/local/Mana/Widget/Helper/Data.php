<?php
/**
 * @category    Mana
 * @package     Mana_Widget
 * @copyright   Copyright (c) http://www.manadev.com
 * @license     http://www.manadev.com/license  Proprietary License
 */
/**
 * Generic helper functions for Mana_Widget module. This class is a must for any module even if empty.
 * @author Mana Team
 */
class Mana_Widget_Helper_Data extends Mage_Core_Helper_Abstract
{
    // INSERT HERE: helper functions that should be available from any other place in the system
}