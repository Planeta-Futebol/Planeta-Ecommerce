Mana.define('Mana/Page/Special/FormContainer/Store', ['jquery', 'Mana/Page/Special/FormContainer'],
function ($, FormContainer)
{
    return FormContainer.extend('Mana/Page/Special/FormContainer/Store', {
    });
});
