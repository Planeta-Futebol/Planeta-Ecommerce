Mana.define('Mana/Page/Special/FormContainer', ['jquery', 'Mana/Admin/Container'],
function ($, Container)
{
    return Container.extend('Mana/Page/Special/FormContainer', {
    });
});
